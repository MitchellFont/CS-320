package tests;

import org.junit.jupiter.api.Test;

import projectOne.Appointment;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AppointmentTest {

    @Test
    void testValidAppointmentCreation() {
        // Create a valid appointment with a future date
        Date futureDate = new Date(System.currentTimeMillis() + 100000); // 100 seconds in the future
        Appointment appointment = new Appointment("1", futureDate, "Doctor's Appointment");

        assertNotNull(appointment, "Appointment should be created successfully.");
        assertEquals("1", appointment.getAppointmentId(), "Appointment ID should match.");
        assertEquals(futureDate, appointment.getAppointmentDate(), "Appointment date should match.");
        assertEquals("Doctor's Appointment", appointment.getDescription(), "Description should match.");
    }

    @Test
    void testInvalidAppointmentId_Null() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Valid description");
        });

        assertEquals("Invalid appointment ID", exception.getMessage(), "Should throw exception for null appointment ID.");
    }

    @Test
    void testInvalidAppointmentId_TooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Valid description"); // 11 characters
        });

        assertEquals("Invalid appointment ID", exception.getMessage(), "Should throw exception for appointment ID longer than 10 characters.");
    }

    @Test
    void testInvalidAppointmentDate_Null() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1", null, "Valid description");
        });

        assertEquals("Invalid appointment date", exception.getMessage(), "Should throw exception for null appointment date.");
    }

    @Test
    void testInvalidAppointmentDate_InPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000); // 100 seconds in the past
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1", pastDate, "Valid description");
        });

        assertEquals("Invalid appointment date", exception.getMessage(), "Should throw exception for past appointment date.");
    }

    @Test
    void testInvalidDescription_Null() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1", futureDate, null);
        });

        assertEquals("Invalid description", exception.getMessage(), "Should throw exception for null description.");
    }

    @Test
    void testInvalidDescription_TooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1", futureDate, "This description is way too long and should fail the validation because it exceeds the fifty character limit.");
        });

        assertEquals("Invalid description", exception.getMessage(), "Should throw exception for description longer than 50 characters.");
    }
}