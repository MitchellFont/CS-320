package tests;

import org.junit.jupiter.api.Test;

import projectOne.Task;

import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("1234567890", "Task Name", "This is a valid description.");
        assertNotNull(task);
        assertEquals("1234567890", task.getUniqueID());
        assertEquals("Task Name", task.getName());
        assertEquals("This is a valid description.", task.getDescription());
    }

    @Test
    public void testInvalidTaskIDTooLong() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Valid Name", "Valid description.");
        });
        assertEquals("Invalid ID", exception.getMessage());
    }

    @Test
    public void testInvalidTaskIDNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Valid Name", "Valid description.");
        });
        assertEquals("Invalid ID", exception.getMessage());
    }

    @Test
    public void testInvalidNameTooLong() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "This name is definitely too long", "Valid description.");
        });
        assertEquals("Invalid name", exception.getMessage());
    }

    @Test
    public void testInvalidNameNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", null, "Valid description.");
        });
        assertEquals("Invalid name", exception.getMessage());
    }

    @Test
    public void testInvalidDescriptionTooLong() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Valid Name", "This description is way too long and exceeds the allowed character limit of fifty characters.");
        });
        assertEquals("Invalid description", exception.getMessage());
    }

    @Test
    public void testInvalidDescriptionNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Valid Name", null);
        });
        assertEquals("Invalid description", exception.getMessage());
    }

    @Test
    public void testSetValidName() {
        Task task = new Task("1234567890", "Initial Name", "Valid description.");
        task.setName("Updated Name");
        assertEquals("Updated Name", task.getName());
    }

    @Test
    public void testSetInvalidNameTooLong() {
        Task task = new Task("1234567890", "Valid Name", "Valid description.");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setName("This name is definitely too long");
        });
        assertEquals("Invalid name", exception.getMessage());
    }

    @Test
    public void testSetInvalidNameNull() {
        Task task = new Task("1234567890", "Valid Name", "Valid description.");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });
        assertEquals("Invalid name", exception.getMessage());
    }

    @Test
    public void testSetValidDescription() {
        Task task = new Task("1234567890", "Valid Name", "Initial description.");
        task.setDescription("Updated description.");
        assertEquals("Updated description.", task.getDescription());
    }

    @Test
    public void testSetInvalidDescriptionTooLong() {
        Task task = new Task("1234567890", "Valid Name", "Valid description.");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("This description is way too long and exceeds the allowed character limit of fifty characters.");
        });
        assertEquals("Invalid description", exception.getMessage());
    }

    @Test
    public void testSetInvalidDescriptionNull() {
        Task task = new Task("1234567890", "Valid Name", "Valid description.");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
        assertEquals("Invalid description", exception.getMessage());
    }
}