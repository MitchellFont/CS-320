package tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import projectOne.Appointment;
import projectOne.AppointmentService;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AppointmentServiceTest {

    private AppointmentService appointmentService;

    @BeforeEach
    void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    void testAddAppointment_Success() {
        Appointment appointment = new Appointment("1", new Date(System.currentTimeMillis() + 10000), "Doctor's Appointment");
        appointmentService.addAppointment(appointment);

        assertEquals(appointment, appointmentService.getAppointment("1"), "Appointment should be added successfully.");
    }

    @Test
    void testAddAppointment_DuplicateID() {
        Appointment appointment1 = new Appointment("1", new Date(System.currentTimeMillis() + 10000), "Doctor's Appointment");
        appointmentService.addAppointment(appointment1);

        Appointment appointment2 = new Appointment("1", new Date(System.currentTimeMillis() + 20000), "Dentist Appointment");

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(appointment2);
        });

        assertEquals("Appointment ID already exists", exception.getMessage(), "Should throw exception for duplicate ID.");
    }

    @Test
    void testDeleteAppointment_Success() {
        Appointment appointment = new Appointment("1", new Date(System.currentTimeMillis() + 10000), "Doctor's Appointment");
        appointmentService.addAppointment(appointment);

        appointmentService.deleteAppointment("1");

        assertNull(appointmentService.getAppointment("1"), "Appointment should be deleted successfully.");
    }

    @Test
    void testDeleteAppointment_NonExistentID() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("999");
        });

        assertEquals("Appointment ID does not exist", exception.getMessage(), "Should throw exception for non-existent ID.");
    }

    @Test
    void testGetAppointment_NonExistentID() {
        assertNull(appointmentService.getAppointment("999"), "Getting non-existent appointment should return null.");
    }

    @Test
    void testAppointmentExists() {
        Appointment appointment = new Appointment("1", new Date(System.currentTimeMillis() + 10000), "Doctor's Appointment");
        appointmentService.addAppointment(appointment);

        assertTrue(appointmentService.appointmentExists("1"), "Appointment should exist.");
        assertFalse(appointmentService.appointmentExists("999"), "Appointment should not exist.");
    }
}