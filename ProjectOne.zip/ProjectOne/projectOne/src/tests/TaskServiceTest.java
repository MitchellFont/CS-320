package tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import projectOne.Task;
import projectOne.TaskService;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddNewTask() {
        taskService.addNewTask("Task 1", "Description 1");
        assertEquals(1, taskService.getTasks().size(), "Task count should be 1.");
    }

    @Test
    public void testDeleteTask() {
        taskService.addNewTask("Task 1", "Description 1");
        String taskId = taskService.getTasks().keySet().iterator().next();
        taskService.deleteTasks(taskId);
        assertEquals(0, taskService.getTasks().size(), "Task count should be 0 after deletion.");
    }

    @Test
    public void testUpdateTask() {
        taskService.addNewTask("Original Task", "Original Description");
        String taskId = taskService.getTasks().keySet().iterator().next();
        
        taskService.updateTasks(taskId, "Updated Task", "Updated Description");

        Task updatedTask = taskService.getTasks().get(taskId);
        assertEquals("Updated Task", updatedTask.getName(), "Task name should be updated");
        assertEquals("Updated Description", updatedTask.getDescription(), "Task description should be updated");
    }

    @Test
    void testUpdateNonExistentTask() {
        TaskService taskService = new TaskService();
        
        // Attempt to update a task with an ID that doesn't exist
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTasks("nonExistentID", "New Name", "New Description");
        });
        
        assertEquals("Task ID does not exist", exception.getMessage(), "Should throw exception when updating a non-existent task.");
    }
}