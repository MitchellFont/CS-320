/* 
 * Mitchell Fontaine
 * 10/09/2024
 * CS-320
 */


package projectOne;

public class Task {
    private String uniqueID;  // Stores the unique ID of the task
    private String fullName;  // Stores the full name of the task
    private String description;  // Stores the description of the task
    
    // Method to validate the unique ID (has to be non-null and <= 10 characters)
    private final boolean validateID(String uniqueID) {
        if (uniqueID == null || uniqueID.length() > 10) {
            return false;  // Return false if invalid
        }
        return true;  // Return true if valid
    }
    
    // Method to validate the name (has to be non-null, <= 20 characters, and not empty)
    private final boolean validateName(String fullName) {
        if (fullName == null || fullName.length() > 20 || fullName.isEmpty()) {
            return false;  // Return false if invalid
        }
        return true;  // Return true if valid
    }
    
    // Method to validate the description (has to be non-null, <= 50 characters, and not empty)
    private final boolean validateDescription(String description) {
        if (description == null || description.length() > 50 || description.isEmpty()) {
            return false;  // Return false if invalid
        }
        return true;  // Return true if valid
    }
    
    // Constructor to initialize a Task object after validating input parameters
    public Task(String uniqueID, String fullName, String description) {
        // Validate the ID and throw an exception if invalid
        if (!this.validateID(uniqueID)) {
            throw new IllegalArgumentException("Invalid ID");
        }
        
        // Validate the name and throw an exception if invalid
        if (!this.validateName(fullName)) {
            throw new IllegalArgumentException("Invalid name");
        }
        
        // Validate the description and throw an exception if invalid
        if (!this.validateDescription(description)) {
            throw new IllegalArgumentException("Invalid description");
        }

        // Set values if all validations pass
        this.uniqueID = uniqueID;  // Task ID is not updatable after this
        this.fullName = fullName;
        this.description = description;
    }
    
    // Getter for unique ID (returns String instead of converting to Integer)
    public String getUniqueID() {
        return uniqueID;
    }
    
    // Getter for full name
    public String getName() {
        return fullName;
    }
    
    // Setter for full name; revalidates before setting
    public void setName(String fullName) {
        if (!this.validateName(fullName)) {
            throw new IllegalArgumentException("Invalid name");
        }
        this.fullName = fullName;
    }
    
    // Getter for description
    public String getDescription() {
        return description;
    }
    
    // Setter for description; revalidates before setting
    public void setDescription(String description) {
        if (!this.validateDescription(description)) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}
