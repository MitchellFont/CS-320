/* 
 * Mitchell Fontaine
 * 10/09/2024
 * CS-320
 */

package projectOne;

import java.util.HashMap;

public class TaskService {
    // Tracks the current ID for generating unique task IDs
    private int currentID = 0;

    // HashMap to store tasks with their unique ID as the key
    private static HashMap<String, Task> tasks = new HashMap<>();

    // Method to add a new task
    public void addNewTask(String _name, String _description) {
        // Convert currentID to a String to use as the task's unique ID
        String stringID = Integer.toString(currentID);

        // Create a new Task object with the generated ID, name, and description
        Task tempTask = new Task(stringID, _name, _description);

        // Add the new Task to the tasks HashMap with the unique ID as the key
        tasks.put(stringID, tempTask);

        // Increment currentID to ensure each new task has a unique ID
        currentID++;
    }

    // Method to delete a task based on its unique ID
    public void deleteTasks(String _ID) {
        // Check if the task with the provided ID exists in the HashMap
        if (tasks.containsKey(_ID)) {
            // Remove the task from the HashMap if it exists
            tasks.remove(_ID);
        }
    }

    // Method to update an existing task's name and description
    public void updateTasks(String _ID, String _newName, String _newDescription) {
        // Check if the task with the provided ID exists in the HashMap
        if (!tasks.containsKey(_ID)) {
            throw new IllegalArgumentException("Task ID does not exist");
        }
        
        // Update the task's name using the setName method
        tasks.get(_ID).setName(_newName);
        // Update the task's description using the setDescription method
        tasks.get(_ID).setDescription(_newDescription);
    }

    // Getter method for tasks
    public HashMap<String, Task> getTasks() {
        return tasks;
    }
}