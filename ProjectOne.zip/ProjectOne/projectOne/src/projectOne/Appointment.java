/* 
 * Mitchell Fontaine
 * 10/09/2024
 * CS-320
 */

package projectOne;

import java.util.Date;

public class Appointment {
    // Fields for appointment ID, appointment date, and description
    private final String appointmentId; // Unique appointment ID
    private final Date appointmentDate; // Date of the appointment
    private final String description;    // Description of the appointment

    // Constructor to create an Appointment object with validation
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Validate the appointment ID: it must not be null and should not exceed 10 characters
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }

        // Validate the appointment date: it must not be null and should be a future date
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }

        // Validate the description: it must not be null and should not exceed 50 characters
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        // Initialize the fields if all validations pass
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Getter for appointment ID (ID is not updatable)
    public String getAppointmentId() {
        return appointmentId;
    }

    // Getter for appointment date
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    // Getter for description
    public String getDescription() {
        return description;
    }
}