/* 
 * Mitchell Fontaine
 * 10/09/2024
 * CS-320
 */

package projectOne;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    // In-memory storage for appointments (using a HashMap with appointmentId as the key)
    private Map<String, Appointment> appointments;

    // Constructor to initialize the appointment service with an empty collection
    public AppointmentService() {
        this.appointments = new HashMap<>();
    }

    // Method to add a new appointment to the service
    public void addAppointment(Appointment appointment) {
        // Check if the appointment ID already exists in the collection
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }

        // Add the appointment to the collection
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    // Method to delete an appointment from the service by its ID
    public void deleteAppointment(String appointmentId) {
        // Check if the appointment with the given ID exists in the collection
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID does not exist");
        }

        // Remove the appointment from the collection
        appointments.remove(appointmentId);
    }

    // Method to retrieve an appointment by its ID (for testing or other uses)
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }

    // Method to check if an appointment exists by its ID
    public boolean appointmentExists(String appointmentId) {
        return appointments.containsKey(appointmentId);
    }
}